public interface Buffer {
    public abstract void insert(Object item);
    public  abstract  Object remove();
}
